<?php
/**
 * Plugin Name: Fake Plugin
 * Plugin URI: https://publishpress.com/
 * Description: A fake plugin for testing dev-workspace scripts
 * Version: 1.0.0
 * Author: PublishPress
 * Author URI: https://publishpress.com/
 * License: GPL-2.0-or-later
 * Text Domain: fake-plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

// Plugin code here
